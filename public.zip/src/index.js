import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './ui/colors.css';
import './ui/effects.css';
import './ui/ui.js';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);