// UI interaction utilities with humanized variables
const ui = {
  init() {
    this.setupTheme();
    this.setupButtons();
    this.setupCards();
  },

  setupTheme() {
    const isDark = localStorage.getItem('darkMode') === 'true';
    if (isDark) this.toggleDarkMode(true);
    
    const themeBtn = document.querySelector('.theme-toggle');
    if (themeBtn) {
      themeBtn.addEventListener('click', () => this.toggleDarkMode());
    }
  },

  toggleDarkMode(state) {
    const body = document.body;
    const isDark = state !== undefined ? state : !body.classList.contains('dark-theme');
    
    body.classList.toggle('dark-theme', isDark);
    localStorage.setItem('darkMode', isDark);
    
    const themeIcon = document.querySelector('.theme-icon');
    if (themeIcon) {
      themeIcon.textContent = isDark ? '☀️' : '🌙';
    }
  },

  setupButtons() {
    const buttons = document.querySelectorAll('.btn-primary, .btn-secondary, .btn-accent');
    
    buttons.forEach(btn => {
      btn.addEventListener('mouseover', () => {
        btn.style.transform = 'translateY(-2px)';
      });
      
      btn.addEventListener('mouseout', () => {
        btn.style.transform = 'translateY(0)';
      });
      
      btn.addEventListener('click', (e) => {
        this.createRipple(btn, e);
      });
    });
  },
  
  createRipple(button, e) {
    const ripple = document.createElement('span');
    const rect = button.getBoundingClientRect();
    
    const size = Math.max(rect.width, rect.height);
    const x = e.clientX - rect.left - size / 2;
    const y = e.clientY - rect.top - size / 2;
    
    ripple.style.width = ripple.style.height = `${size}px`;
    ripple.style.left = `${x}px`;
    ripple.style.top = `${y}px`;
    ripple.classList.add('ripple');
    
    button.appendChild(ripple);
    
    setTimeout(() => {
      ripple.remove();
    }, 600);
  },
  
  setupCards() {
    const cards = document.querySelectorAll('.card');
    
    cards.forEach(card => {
      card.addEventListener('mouseover', () => {
        card.style.transform = 'translateY(-5px)';
        card.style.boxShadow = '0 8px 16px rgba(0, 0, 0, 0.2)';
      });
      
      card.addEventListener('mouseout', () => {
        card.style.transform = 'translateY(0)';
        card.style.boxShadow = '0 4px 8px rgba(0, 0, 0, 0.1)';
      });
    });
  }
};

// Initialize UI when DOM is loaded
document.addEventListener('DOMContentLoaded', () => ui.init());

export default ui;