import React from 'react';
import './Sidebar.css';

function Sidebar({ isOpen }) {
  return (
    <aside className={`sidebar ${isOpen ? 'open' : 'closed'}`}>
      <div className="sidebar-content">
        <div className="sidebar-section">
          <h3 className="sidebar-title">Menu</h3>
          <ul className="sidebar-menu">
            <li className="menu-item active">
              <span className="menu-icon">📊</span>
              <span className="menu-text">Dashboard</span>
            </li>
            <li className="menu-item">
              <span className="menu-icon">📁</span>
              <span className="menu-text">Repository</span>
            </li>
            <li className="menu-item">
              <span className="menu-icon">👨‍🎓</span>
              <span className="menu-text">Students</span>
            </li>
            <li className="menu-item">
              <span className="menu-icon">📝</span>
              <span className="menu-text">Publications</span>
            </li>
            <li className="menu-item">
              <span className="menu-icon">👨‍🏫</span>
              <span className="menu-text">Supervisors</span>
            </li>
          </ul>
        </div>
        
        <div className="sidebar-section">
          <h3 className="sidebar-title">Categories</h3>
          <ul className="category-list">
            <li className="category-item">
              <span className="category-name">Computer Science</span>
              <span className="category-count">42</span>
            </li>
            <li className="category-item">
              <span className="category-name">Electrical Engineering</span>
              <span className="category-count">28</span>
            </li>
            <li className="category-item">
              <span className="category-name">Mathematics</span>
              <span className="category-count">15</span>
            </li>
            <li className="category-item">
              <span className="category-name">Business</span>
              <span className="category-count">31</span>
            </li>
          </ul>
        </div>
        
        <div className="sidebar-footer">
          <button className="btn-primary">
            <span>Add New Project</span> <span>+</span>
          </button>
        </div>
      </div>
    </aside>
  );
}

export default Sidebar;