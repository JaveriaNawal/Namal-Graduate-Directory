import React from 'react';
import './Dashboard.css';

function Dashboard({ sidebarOpen }) {
  const recentProjects = [
    { id: 1, title: "Machine Learning for Healthcare", author: "Ali Ahmed", category: "Computer Science", date: "May 5, 2025" },
    { id: 2, title: "Renewable Energy Solutions", author: "Sara Khan", category: "Electrical Engineering", date: "May 3, 2025" },
    { id: 3, title: "Visualizing Abstract Algebra", author: "Usman Ali", category: "Mathematics", date: "May 1, 2025" },
    { id: 4, title: "Business Process Automation", author: "Fatima Zahra", category: "Business", date: "April 28, 2025" },
  ];

  const topStudents = [
    { id: 1, name: "Zainab Malik", department: "Computer Science", projects: 5, publications: 3 },
    { id: 2, name: "Ahmed Hassan", department: "Electrical Engineering", projects: 4, publications: 2 },
    { id: 3, name: "Farah Siddiqui", department: "Business", projects: 3, publications: 4 },
  ];

  return (
    <div className={`dashboard ${sidebarOpen ? '' : 'sidebar-collapsed'}`}>
      <div className="dashboard-header">
        <h1 className="page-title">Dashboard</h1>
        <div className="date-display">Friday, May 09, 2025</div>
      </div>
      
      <div className="stat-cards">
        <div className="stat-card">
          <div className="stat-icon">📚</div>
          <div className="stat-content">
            <div className="stat-value">235</div>
            <div className="stat-label">Total Projects</div>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">👨‍🎓</div>
          <div className="stat-content">
            <div className="stat-value">187</div>
            <div className="stat-label">Active Students</div>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">📝</div>
          <div className="stat-content">
            <div className="stat-value">89</div>
            <div className="stat-label">Publications</div>
          </div>
        </div>
        
        <div className="stat-card">
          <div className="stat-icon">👨‍🏫</div>
          <div className="stat-content">
            <div className="stat-value">42</div>
            <div className="stat-label">Supervisors</div>
          </div>
        </div>
      </div>
      
      <div className="dashboard-row">
        <div className="dashboard-card recent-projects">
          <div className="card-header">
            <h2 className="card-title">Recent Projects</h2>
            <button className="btn-accent view-all-btn">View All</button>
          </div>
          <div className="project-list">
            {recentProjects.map(project => (
              <div className="project-item" key={project.id}>
                <div className="project-info">
                  <h3 className="project-title">{project.title}</h3>
                  <div className="project-meta">
                    <span className="project-author">{project.author}</span>
                    <span className="project-date">{project.date}</span>
                  </div>
                </div>
                <div className="project-category">
                  <span className="tag">{project.category}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="dashboard-card top-students">
          <div className="card-header">
            <h2 className="card-title">Top Students</h2>
            <button className="btn-accent view-all-btn">View All</button>
          </div>
          <div className="student-list">
            {topStudents.map(student => (
              <div className="student-item" key={student.id}>
                <div className="student-avatar">
                  {student.name.charAt(0)}
                </div>
                <div className="student-info">
                  <h3 className="student-name">{student.name}</h3>
                  <div className="student-department">{student.department}</div>
                </div>
                <div className="student-stats">
                  <div className="stat">
                    <div className="stat-value">{student.projects}</div>
                    <div className="stat-label">Projects</div>
                  </div>
                  <div className="stat">
                    <div className="stat-value">{student.publications}</div>
                    <div className="stat-label">Publications</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;