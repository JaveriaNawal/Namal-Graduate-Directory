import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <footer className="footer">
      <div className="container footer-container">
        <div className="footer-left">
          <div className="footer-logo">Graduate Repository</div>
          <div className="footer-tagline">Preserving knowledge for future generations</div>
        </div>
        
        <div className="footer-links">
          <a href="/about">About</a>
          <a href="/privacy">Privacy Policy</a>
          <a href="/terms">Terms of Use</a>
          <a href="/contact">Contact</a>
        </div>
        
        <div className="footer-right">
          <div className="copyright">© 2025 Namal Graduate Repository</div>
        </div>
      </div>
    </footer>
  );
}

export default Footer;