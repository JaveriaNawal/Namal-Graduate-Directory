import React from 'react';
import './Header.css';

function Header({ toggleSidebar }) {
  return (
    <header className="header">
      <div className="container header-container">
        <div className="header-left">
          <button className="menu-toggle" onClick={toggleSidebar}>
            <span className="menu-icon">☰</span>
          </button>
          <div className="logo">Graduate Repository</div>
        </div>
        
        <nav className="navbar">
          <a href="/" className="nav-link active">Home</a>
          <a href="/projects" className="nav-link">Projects</a>
          <a href="/students" className="nav-link">Students</a>
          <a href="/publications" className="nav-link">Publications</a>
        </nav>
        
        <div className="header-right">
          <div className="search-box">
            <input type="text" placeholder="Search..." />
            <button className="search-btn">🔍</button>
          </div>
          <button className="theme-toggle">
            <span className="theme-icon">🌙</span>
          </button>
          <div className="user-profile">
            <img src="/api/placeholder/32/32" alt="User" className="avatar" />
            <span className="username">User</span>
          </div>
        </div>
      </div>
    </header>
  );
}

export default Header;