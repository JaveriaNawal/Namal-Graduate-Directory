import React, { useState } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import Footer from './components/Footer';
import './ui/colors.css';
import './ui/effects.css';
import './App.css';

function App() {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <div className="app">
      <Header toggleSidebar={toggleSidebar} />
      <main className="main-content">
        <Sidebar isOpen={sidebarOpen} />
        <Dashboard sidebarOpen={sidebarOpen} />
      </main>
      <Footer />
    </div>
  );
}

export default App;